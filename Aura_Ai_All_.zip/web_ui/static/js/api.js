// API wrapper functions for Aura AI Assistant

class AuraAPI {
    constructor() {
        this.baseURL = '';
        this.isUnlocked = false;
    }

    // Utility method for making API requests
    async request(endpoint, options = {}) {
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
            },
        };

        const config = { ...defaultOptions, ...options };
        
        try {
            const response = await fetch(endpoint, config);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            // Handle different response types
            const contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                return await response.json();
            } else if (contentType && contentType.includes('audio/')) {
                return response.blob();
            } else if (contentType && contentType.includes('image/')) {
                return response.blob();
            } else {
                return await response.text();
            }
        } catch (error) {
            console.error('API request failed:', error);
            throw error;
        }
    }

    // Face Recognition APIs
    async addFace(formData) {
        return await this.request('/face_add', {
            method: 'POST',
            body: formData,
            headers: {} // Remove default JSON header for FormData
        });
    }

    async recognizeFace(formData) {
        return await this.request('/face_check', {
            method: 'POST',
            body: formData,
            headers: {}
        });
    }

    async detectFaces(formData) {
        return await this.request('/api/face_detect', {
            method: 'POST',
            body: formData,
            headers: {}
        });
    }

    // Emotion Detection APIs
    async detectEmotion(formData) {
        return await this.request('/emotion', {
            method: 'POST',
            body: formData,
            headers: {}
        });
    }

    async getEmotionTimeline() {
        return await this.request('/api/emotion_timeline');
    }

    async getLatestEmotion() {
        return await this.request('/latest_emotion');
    }

    async setEmoji(emoji) {
        return await this.request('/api/emoji', {
            method: 'POST',
            body: JSON.stringify({ emoji })
        });
    }

    // Memory APIs
    async getMemories() {
        return await this.request('/api/memory');
    }

    async searchMemory(query) {
        return await this.request('/api/memory_answer', {
            method: 'POST',
            body: JSON.stringify({ query })
        });
    }

    async addMemory(question, answer) {
        // This would typically save to the server
        return await this.request('/api/add_memory', {
            method: 'POST',
            body: JSON.stringify({ question, answer })
        });
    }

    // Voice/Audio APIs
    async speechToText(formData) {
        return await this.request('/stt', {
            method: 'POST',
            body: formData,
            headers: {}
        });
    }

    async textToSpeech(text, lang = 'ben') {
        return await this.request('/tts', {
            method: 'POST',
            body: JSON.stringify({ text })
        });
    }

    async speak(text, lang = 'ben') {
        return await this.request('/api/speak', {
            method: 'POST',
            body: JSON.stringify({ text, lang })
        });
    }

    async playAudio(file) {
        return await this.request(`/api/play_audio`, {
            method: 'POST',
            body: JSON.stringify({ file })
        });
    }

    // Camera APIs
    async captureImage(formData) {
        return await this.request('/api/capture', {
            method: 'POST',
            body: formData,
            headers: {}
        });
    }

    async uploadImage(formData) {
        return await this.request('/upload', {
            method: 'POST',
            body: formData,
            headers: {}
        });
    }

    async getLiveFrame() {
        return await this.request('/api/live_frame');
    }

    async getSurveillanceTimeline() {
        return await this.request('/timeline');
    }

    // AI Chat APIs
    async aiConsole(query) {
        return await this.request('/api/ai_console', {
            method: 'POST',
            body: JSON.stringify({ query })
        });
    }

    async gptChat(msg) {
        return await this.request('/api/gpt_chat', {
            method: 'POST',
            body: JSON.stringify({ msg })
        });
    }

    async getWeather(location) {
        return await this.request('/api/weather', {
            method: 'POST',
            body: JSON.stringify({ location })
        });
    }

    // OCR APIs
    async ocrImage(formData) {
        return await this.request('/ocr_image', {
            method: 'POST',
            body: formData,
            headers: {}
        });
    }

    async translateText(text, lang) {
        return await this.request('/translate', {
            method: 'POST',
            body: JSON.stringify({ text, lang })
        });
    }

    // WiFi APIs
    async scanWiFi() {
        return await this.request('/api/wifi_scan');
    }

    async connectWiFi(ssid, password) {
        return await this.request('/api/wifi_connect', {
            method: 'POST',
            body: JSON.stringify({ ssid, password })
        });
    }

    // Sensor APIs
    async getSensorData() {
        return await this.request('/api/sensors');
    }

    // System APIs
    async executeCommand(cmd) {
        return await this.request('/api/command', {
            method: 'POST',
            body: JSON.stringify({ cmd })
        });
    }

    async unlock(pin) {
        const result = await this.request('/api/unlock', {
            method: 'POST',
            body: JSON.stringify({ pin })
        });
        this.isUnlocked = result.unlocked;
        return result;
    }

    async otaUpdate(formData) {
        return await this.request('/api/ota', {
            method: 'POST',
            body: formData,
            headers: {}
        });
    }

    async backupData() {
        return await this.request('/api/backup');
    }

    async restoreData(formData) {
        return await this.request('/api/restore', {
            method: 'POST',
            body: formData,
            headers: {}
        });
    }

    async syncFirebase() {
        return await this.request('/api/sync_firebase');
    }

    async driveBackup() {
        return await this.request('/api/drive_backup', {
            method: 'POST'
        });
    }

    async getStorageInfo() {
        return await this.request('/api/storage_info');
    }

    async getNotifications() {
        return await this.request('/api/notifications');
    }

    async getUsageStats() {
        return await this.request('/api/usage_stats');
    }

    async activateDreamMode() {
        return await this.request('/api/dream_mode', {
            method: 'POST'
        });
    }

    async detectGesture() {
        return await this.request('/api/gesture', {
            method: 'POST'
        });
    }

    async getWebRTCStatus() {
        return await this.request('/api/webrtc_status');
    }

    async getSystemStatus() {
        return await this.request('/api/status');
    }

    async scheduleTask(time, task) {
        return await this.request('/api/schedule', {
            method: 'POST',
            body: JSON.stringify({ time, task })
        });
    }

    async setReminder(data) {
        return await this.request('/api/reminder', {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }

    async setProfile(name) {
        return await this.request('/api/profile', {
            method: 'POST',
            body: JSON.stringify({ name })
        });
    }

    async togglePlugin(plugin) {
        return await this.request('/api/plugin_toggle', {
            method: 'POST',
            body: JSON.stringify({ plugin })
        });
    }

    async addCustomCommand(cmd) {
        return await this.request('/api/custom_command', {
            method: 'POST',
            body: JSON.stringify({ cmd })
        });
    }
}

// Create global API instance
window.auraAPI = new AuraAPI();

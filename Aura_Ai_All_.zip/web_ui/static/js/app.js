// Main application logic for Aura AI Assistant Dashboard

class AuraDashboard {
    constructor() {
        this.currentSection = 'dashboard';
        this.charts = {};
        this.isUnlocked = false;
        this.refreshIntervals = {};
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupNavigation();
        this.setupCharts();
        this.loadDashboard();
        this.startAutoRefresh();
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-link[data-section]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = e.target.getAttribute('data-section');
                this.showSection(section);
            });
        });

        // PIN Unlock
        document.getElementById('unlock-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleUnlock();
        });

        // Face Recognition
        this.setupFaceRecognitionEvents();
        
        // Emotion Detection
        this.setupEmotionDetectionEvents();
        
        // Memory Management
        this.setupMemoryEvents();
        
        // Voice Controls
        this.setupVoiceEvents();
        
        // Camera
        this.setupCameraEvents();
        
        // AI Chat
        this.setupAIChatEvents();
        
        // OCR
        this.setupOCREvents();
        
        // WiFi Manager
        this.setupWiFiEvents();
        
        // Sensors
        this.setupSensorEvents();
        
        // System
        this.setupSystemEvents();

        // Global refresh buttons
        document.getElementById('refresh-dashboard')?.addEventListener('click', () => {
            this.loadDashboard();
        });

        // Image preview handlers
        this.setupImagePreviews();
    }

    setupNavigation() {
        // Handle section switching
        const navLinks = document.querySelectorAll('.nav-link[data-section]');
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = e.target.getAttribute('data-section');
                this.showSection(section);
                
                // Update active state
                navLinks.forEach(l => l.classList.remove('active'));
                e.target.classList.add('active');
            });
        });
    }

    showSection(sectionName) {
        // Hide all sections
        document.querySelectorAll('.content-section').forEach(section => {
            section.style.display = 'none';
        });
        
        // Show target section
        const targetSection = document.getElementById(sectionName);
        if (targetSection) {
            targetSection.style.display = 'block';
            targetSection.classList.add('fade-in');
            this.currentSection = sectionName;
            
            // Load section-specific data
            this.loadSectionData(sectionName);
        }
    }

    async loadSectionData(sectionName) {
        switch (sectionName) {
            case 'dashboard':
                await this.loadDashboard();
                break;
            case 'memory-gallery':
                await this.loadMemories();
                break;
            case 'sensors':
                await this.loadSensorData();
                break;
            case 'wifi-manager':
                // Data loaded on demand
                break;
            case 'system':
                await this.loadStorageInfo();
                break;
        }
    }

    setupCharts() {
        // Setup sensor chart
        const sensorCtx = document.getElementById('sensorChart')?.getContext('2d');
        if (sensorCtx) {
            this.charts.sensor = new Chart(sensorCtx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Temperature',
                        data: [],
                        borderColor: 'rgb(75, 192, 192)',
                        tension: 0.1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        // Setup emotion chart
        const emotionCtx = document.getElementById('emotionChart')?.getContext('2d');
        if (emotionCtx) {
            this.charts.emotion = new Chart(emotionCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Happy', 'Sad', 'Angry', 'Neutral', 'Surprise'],
                    datasets: [{
                        data: [0, 0, 0, 0, 0],
                        backgroundColor: [
                            '#FF6384',
                            '#36A2EB',
                            '#FFCE56',
                            '#4BC0C0',
                            '#9966FF'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }

        // Setup sensor history chart
        const sensorHistoryCtx = document.getElementById('sensorHistoryChart')?.getContext('2d');
        if (sensorHistoryCtx) {
            this.charts.sensorHistory = new Chart(sensorHistoryCtx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [
                        {
                            label: 'Temperature (°C)',
                            data: [],
                            borderColor: 'rgb(255, 99, 132)',
                            backgroundColor: 'rgba(255, 99, 132, 0.2)',
                        },
                        {
                            label: 'Humidity (%)',
                            data: [],
                            borderColor: 'rgb(54, 162, 235)',
                            backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: {
                        mode: 'index',
                        intersect: false,
                    },
                    scales: {
                        x: {
                            display: true,
                            title: {
                                display: true,
                                text: 'Time'
                            }
                        },
                        y: {
                            display: true,
                            title: {
                                display: true,
                                text: 'Value'
                            }
                        }
                    }
                }
            });
        }
    }

    async loadDashboard() {
        try {
            this.showLoading(true);

            // Load usage stats
            const stats = await auraAPI.getUsageStats();
            document.getElementById('uptime-hours').textContent = stats.uptime_hours || '--';
            document.getElementById('commands-processed').textContent = stats.commands_processed || '--';

            // Load current emotion
            const emotion = await auraAPI.getLatestEmotion();
            document.getElementById('current-emotion').textContent = emotion.emotion || '--';

            // Load memory count
            const memories = await auraAPI.getMemories();
            document.getElementById('memory-count').textContent = memories.length || '--';

            // Load notifications
            await this.loadNotifications();

            // Refresh live camera feed
            this.refreshCameraFeed();

            // Load sensor data for chart
            await this.loadSensorChart();

        } catch (error) {
            console.error('Error loading dashboard:', error);
            this.showError('Failed to load dashboard data');
        } finally {
            this.showLoading(false);
        }
    }

    async loadNotifications() {
        try {
            const notifications = await auraAPI.getNotifications();
            const container = document.getElementById('notifications-list');
            
            if (notifications.length === 0) {
                container.innerHTML = '<p class="text-muted">No new notifications</p>';
                return;
            }

            container.innerHTML = notifications.map(notif => `
                <div class="alert alert-info alert-dismissible fade show" role="alert">
                    <strong>${notif.title}</strong>
                    <small class="text-muted d-block">${new Date(notif.time).toLocaleString()}</small>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `).join('');
        } catch (error) {
            console.error('Error loading notifications:', error);
        }
    }

    async loadSensorChart() {
        try {
            const sensorData = await auraAPI.getSensorData();
            const now = new Date().toLocaleTimeString();
            
            if (this.charts.sensor) {
                const chart = this.charts.sensor;
                chart.data.labels.push(now);
                chart.data.datasets[0].data.push(sensorData.temperature);
                
                // Keep only last 10 data points
                if (chart.data.labels.length > 10) {
                    chart.data.labels.shift();
                    chart.data.datasets[0].data.shift();
                }
                
                chart.update();
            }
        } catch (error) {
            console.error('Error loading sensor chart:', error);
        }
    }

    refreshCameraFeed() {
        const liveFrame = document.getElementById('live-feed');
        if (liveFrame) {
            liveFrame.src = '/api/live_frame?' + new Date().getTime();
        }

        document.getElementById('refresh-feed')?.addEventListener('click', () => {
            this.refreshCameraFeed();
        });
    }

    setupFaceRecognitionEvents() {
        // Add face form
        document.getElementById('add-face-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleAddFace(e);
        });

        // Recognize face form
        document.getElementById('recognize-face-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleRecognizeFace(e);
        });

        // Detect faces form
        document.getElementById('detect-face-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleDetectFaces(e);
        });
    }

    async handleAddFace(e) {
        try {
            this.showLoading(true);
            const formData = new FormData();
            formData.append('name', document.getElementById('face-name').value);
            formData.append('image', document.getElementById('face-image').files[0]);

            const result = await auraAPI.addFace(formData);
            this.showSuccess('Face added successfully!');
            document.getElementById('add-face-form').reset();
            document.getElementById('face-preview').style.display = 'none';
        } catch (error) {
            this.showError('Failed to add face: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    async handleRecognizeFace(e) {
        try {
            this.showLoading(true);
            const formData = new FormData();
            formData.append('image', document.getElementById('recognize-image').files[0]);

            const result = await auraAPI.recognizeFace(formData);
            const resultDiv = document.getElementById('recognition-result');
            
            if (result.matched) {
                resultDiv.innerHTML = `
                    <div class="recognition-result recognition-success">
                        <h5><i class="fas fa-check-circle me-2"></i>Match Found!</h5>
                        <p>Recognized as: <strong>${result.name}</strong></p>
                    </div>
                `;
            } else {
                resultDiv.innerHTML = `
                    <div class="recognition-result recognition-failed">
                        <h5><i class="fas fa-times-circle me-2"></i>No Match</h5>
                        <p>Person not recognized</p>
                    </div>
                `;
            }
        } catch (error) {
            this.showError('Face recognition failed: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    async handleDetectFaces(e) {
        try {
            this.showLoading(true);
            const formData = new FormData();
            formData.append('image', document.getElementById('detect-image').files[0]);

            const result = await auraAPI.detectFaces(formData);
            const resultDiv = document.getElementById('detection-result');
            
            resultDiv.innerHTML = `
                <div class="recognition-result recognition-success">
                    <h5><i class="fas fa-eye me-2"></i>Detection Complete</h5>
                    <p>Found <strong>${result.faces_detected}</strong> face(s)</p>
                    ${result.faces.map(face => `
                        <small class="d-block">Face at: x=${face.x}, y=${face.y}, w=${face.w}, h=${face.h}</small>
                    `).join('')}
                </div>
            `;
        } catch (error) {
            this.showError('Face detection failed: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    setupEmotionDetectionEvents() {
        // Emotion detection form
        document.getElementById('emotion-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleEmotionDetection(e);
        });

        // Emoji buttons
        document.querySelectorAll('.emoji-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const emoji = e.target.getAttribute('data-emoji');
                await this.setEmoji(emoji);
            });
        });

        // Refresh emotion timeline
        document.getElementById('refresh-emotion-timeline')?.addEventListener('click', () => {
            this.loadEmotionTimeline();
        });
    }

    async handleEmotionDetection(e) {
        try {
            this.showLoading(true);
            const formData = new FormData();
            formData.append('image', document.getElementById('emotion-image').files[0]);

            const result = await auraAPI.detectEmotion(formData);
            const resultDiv = document.getElementById('emotion-result');
            
            resultDiv.innerHTML = `
                <div class="recognition-result recognition-success">
                    <h5><i class="fas fa-smile me-2"></i>Emotion Detected</h5>
                    <p>Detected emotion: <strong>${result.emotion}</strong></p>
                    <p>Emoji: <span style="font-size: 2rem;">${result.emoji}</span></p>
                </div>
            `;

            // Update emotion chart
            this.updateEmotionChart(result.emotion);
        } catch (error) {
            this.showError('Emotion detection failed: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    async setEmoji(emoji) {
        try {
            await auraAPI.setEmoji(emoji);
            this.showSuccess(`Emoji set to ${emoji}`);
        } catch (error) {
            this.showError('Failed to set emoji: ' + error.message);
        }
    }

    updateEmotionChart(emotion) {
        if (!this.charts.emotion) return;

        const chart = this.charts.emotion;
        const emotions = ['happy', 'sad', 'angry', 'neutral', 'surprise'];
        const index = emotions.indexOf(emotion.toLowerCase());
        
        if (index !== -1) {
            chart.data.datasets[0].data[index]++;
            chart.update();
        }
    }

    async loadEmotionTimeline() {
        try {
            const timeline = await auraAPI.getEmotionTimeline();
            // Update emotion chart with timeline data
            // Implementation depends on your timeline data structure
        } catch (error) {
            console.error('Error loading emotion timeline:', error);
        }
    }

    setupMemoryEvents() {
        // Memory search form
        document.getElementById('memory-search-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleMemorySearch(e);
        });

        // Add memory form
        document.getElementById('add-memory-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleAddMemory(e);
        });

        // Refresh memories
        document.getElementById('refresh-memories')?.addEventListener('click', () => {
            this.loadMemories();
        });

        // Backup memories
        document.getElementById('backup-memories')?.addEventListener('click', async () => {
            await this.backupMemories();
        });
    }

    async handleMemorySearch(e) {
        try {
            this.showLoading(true);
            const query = document.getElementById('memory-query').value;
            const result = await auraAPI.searchMemory(query);
            
            const resultDiv = document.getElementById('memory-search-result');
            resultDiv.innerHTML = `
                <div class="memory-card">
                    <div class="memory-question">Q: ${query}</div>
                    <div class="memory-answer">A: ${result.answer}</div>
                </div>
            `;
        } catch (error) {
            this.showError('Memory search failed: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    async handleAddMemory(e) {
        try {
            this.showLoading(true);
            const question = document.getElementById('memory-question').value;
            const answer = document.getElementById('memory-answer').value;
            
            await auraAPI.addMemory(question, answer);
            this.showSuccess('Memory added successfully!');
            document.getElementById('add-memory-form').reset();
            await this.loadMemories();
        } catch (error) {
            this.showError('Failed to add memory: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    async loadMemories() {
        try {
            const memories = await auraAPI.getMemories();
            const container = document.getElementById('memory-timeline');
            
            if (memories.length === 0) {
                container.innerHTML = '<p class="text-muted">No memories found</p>';
                return;
            }

            container.innerHTML = memories.map(memory => `
                <div class="timeline-item">
                    <div class="timeline-time">${new Date(memory.time).toLocaleString()}</div>
                    <div class="timeline-content">
                        <div class="memory-question">Q: ${memory.question}</div>
                        <div class="memory-answer">A: ${memory.answer}</div>
                    </div>
                </div>
            `).join('');
        } catch (error) {
            console.error('Error loading memories:', error);
        }
    }

    async backupMemories() {
        try {
            const blob = await auraAPI.backupData();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'aura_memories_backup.json';
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
            this.showSuccess('Backup downloaded successfully!');
        } catch (error) {
            this.showError('Backup failed: ' + error.message);
        }
    }

    setupVoiceEvents() {
        // STT form
        document.getElementById('stt-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleSpeechToText(e);
        });

        // TTS form
        document.getElementById('tts-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleTextToSpeech(e);
        });

        // Play audio buttons
        document.querySelectorAll('.play-audio-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const file = e.target.getAttribute('data-file');
                await this.playAudio(file);
            });
        });

        document.getElementById('play-latest-tts')?.addEventListener('click', async () => {
            // Play the latest TTS generated audio
            await this.playAudio('latest_tts.mp3');
        });
    }

    async handleSpeechToText(e) {
        try {
            this.showLoading(true);
            const formData = new FormData();
            formData.append('audio', document.getElementById('audio-file').files[0]);

            const result = await auraAPI.speechToText(formData);
            document.getElementById('stt-result').innerHTML = `
                <div class="alert alert-success">
                    <h6>Transcribed Text:</h6>
                    <p>${result.text}</p>
                </div>
            `;
        } catch (error) {
            this.showError('Speech to text failed: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    async handleTextToSpeech(e) {
        try {
            this.showLoading(true);
            const text = document.getElementById('tts-text').value;
            const lang = document.getElementById('tts-lang').value;

            const audioBlob = await auraAPI.speak(text, lang);
            const audioUrl = URL.createObjectURL(audioBlob);
            
            document.getElementById('tts-result').innerHTML = `
                <div class="alert alert-success">
                    <h6>Generated Audio:</h6>
                    <audio controls>
                        <source src="${audioUrl}" type="audio/mpeg">
                        Your browser does not support the audio element.
                    </audio>
                </div>
            `;
        } catch (error) {
            this.showError('Text to speech failed: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    async playAudio(filename) {
        try {
            const audioBlob = await auraAPI.playAudio(filename);
            const audioUrl = URL.createObjectURL(audioBlob);
            const audio = new Audio(audioUrl);
            audio.play();
        } catch (error) {
            this.showError('Failed to play audio: ' + error.message);
        }
    }

    setupCameraEvents() {
        // Capture form
        document.getElementById('capture-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleCaptureImage(e);
        });

        // Upload form
        document.getElementById('upload-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleUploadImage(e);
        });

        // Refresh timeline
        document.getElementById('refresh-timeline')?.addEventListener('click', () => {
            this.loadSurveillanceTimeline();
        });
    }

    async handleCaptureImage(e) {
        try {
            this.showLoading(true);
            const formData = new FormData();
            formData.append('image', document.getElementById('capture-image').files[0]);
            formData.append('desc', document.getElementById('capture-desc').value || 'No description');

            const result = await auraAPI.captureImage(formData);
            this.showSuccess('Image captured and saved to memory!');
            document.getElementById('capture-form').reset();
        } catch (error) {
            this.showError('Image capture failed: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    async handleUploadImage(e) {
        try {
            this.showLoading(true);
            const formData = new FormData();
            formData.append('image', document.getElementById('upload-image').files[0]);

            const result = await auraAPI.uploadImage(formData);
            const resultDiv = document.getElementById('upload-result');
            resultDiv.innerHTML = `
                <div class="alert alert-success">
                    <h6>Upload Successful!</h6>
                    <p>Filename: ${result.filename}</p>
                </div>
            `;
        } catch (error) {
            this.showError('Image upload failed: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    async loadSurveillanceTimeline() {
        try {
            const timeline = await auraAPI.getSurveillanceTimeline();
            const container = document.getElementById('surveillance-timeline');
            
            if (timeline.length === 0) {
                container.innerHTML = '<p class="text-muted">No surveillance data found</p>';
                return;
            }

            container.innerHTML = timeline.map(item => `
                <div class="timeline-item">
                    <div class="timeline-time">${new Date(item.timestamp).toLocaleString()}</div>
                    <div class="timeline-content">
                        <p>File: ${item.filename}</p>
                    </div>
                </div>
            `).join('');
        } catch (error) {
            console.error('Error loading surveillance timeline:', error);
        }
    }

    setupAIChatEvents() {
        // AI Console form
        document.getElementById('ai-console-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleAIConsole(e);
        });

        // GPT Chat form
        document.getElementById('gpt-chat-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleGPTChat(e);
        });

        // Weather form
        document.getElementById('weather-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleWeather(e);
        });
    }

    async handleAIConsole(e) {
        try {
            this.showLoading(true);
            const query = document.getElementById('ai-query').value;
            const result = await auraAPI.aiConsole(query);
            
            document.getElementById('ai-console-result').innerHTML = `
                <div class="alert alert-info">
                    <h6>AI Response:</h6>
                    <p>${result.response}</p>
                </div>
            `;
            
            document.getElementById('ai-query').value = '';
        } catch (error) {
            this.showError('AI console failed: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    async handleGPTChat(e) {
        try {
            const message = document.getElementById('chat-message').value;
            const chatMessages = document.getElementById('chat-messages');
            
            // Add user message
            chatMessages.innerHTML += `
                <div class="chat-message user">
                    ${message}
                </div>
            `;
            
            document.getElementById('chat-message').value = '';
            chatMessages.scrollTop = chatMessages.scrollHeight;
            
            // Get AI response
            const result = await auraAPI.gptChat(message);
            
            // Add bot response
            chatMessages.innerHTML += `
                <div class="chat-message bot">
                    ${result.reply}
                </div>
            `;
            
            chatMessages.scrollTop = chatMessages.scrollHeight;
        } catch (error) {
            this.showError('GPT chat failed: ' + error.message);
        }
    }

    async handleWeather(e) {
        try {
            this.showLoading(true);
            const location = document.getElementById('weather-location').value;
            const result = await auraAPI.getWeather(location);
            
            document.getElementById('weather-result').innerHTML = `
                <div class="alert alert-info">
                    <h6>Weather for ${result.location}:</h6>
                    <p>Temperature: ${result.temperature}</p>
                    <p>Condition: ${result.condition}</p>
                </div>
            `;
        } catch (error) {
            this.showError('Weather request failed: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    setupOCREvents() {
        // OCR form
        document.getElementById('ocr-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleOCR(e);
        });

        // Translate form
        document.getElementById('translate-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleTranslate(e);
        });

        // Copy OCR text
        document.getElementById('copy-ocr-text')?.addEventListener('click', () => {
            this.copyOCRText();
        });

        // Speak OCR text
        document.getElementById('speak-ocr-text')?.addEventListener('click', async () => {
            await this.speakOCRText();
        });
    }

    async handleOCR(e) {
        try {
            this.showLoading(true);
            const formData = new FormData();
            formData.append('image', document.getElementById('ocr-image').files[0]);

            const result = await auraAPI.ocrImage(formData);
            const resultDiv = document.getElementById('ocr-result');
            
            resultDiv.innerHTML = `<div class="ocr-result">${result.text}</div>`;
            resultDiv.setAttribute('data-text', result.text);
            
            // Show action buttons
            document.getElementById('copy-ocr-text').style.display = 'inline-block';
            document.getElementById('speak-ocr-text').style.display = 'inline-block';
            
            // Auto-populate translate form
            document.getElementById('translate-text').value = result.text;
        } catch (error) {
            this.showError('OCR failed: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    async handleTranslate(e) {
        try {
            this.showLoading(true);
            const text = document.getElementById('translate-text').value;
            const lang = document.getElementById('translate-lang').value;
            
            const result = await auraAPI.translateText(text, lang);
            
            document.getElementById('translate-result').innerHTML = `
                <div class="alert alert-success">
                    <h6>Translated Text:</h6>
                    <p>${result.translated}</p>
                </div>
            `;
        } catch (error) {
            this.showError('Translation failed: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    copyOCRText() {
        const text = document.getElementById('ocr-result').getAttribute('data-text');
        if (text && navigator.clipboard) {
            navigator.clipboard.writeText(text);
            this.showSuccess('Text copied to clipboard!');
        }
    }

    async speakOCRText() {
        try {
            const text = document.getElementById('ocr-result').getAttribute('data-text');
            if (text) {
                const audioBlob = await auraAPI.speak(text, 'ben');
                const audioUrl = URL.createObjectURL(audioBlob);
                const audio = new Audio(audioUrl);
                audio.play();
            }
        } catch (error) {
            this.showError('Failed to speak text: ' + error.message);
        }
    }

    setupWiFiEvents() {
        // Scan WiFi button
        document.getElementById('scan-wifi')?.addEventListener('click', async () => {
            await this.scanWiFi();
        });

        // WiFi connect form
        document.getElementById('wifi-connect-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleWiFiConnect(e);
        });
    }

    async scanWiFi() {
        try {
            this.showLoading(true);
            const networks = await auraAPI.scanWiFi();
            const container = document.getElementById('wifi-networks');
            
            if (networks.length === 0) {
                container.innerHTML = '<p class="text-muted">No WiFi networks found</p>';
                return;
            }

            container.innerHTML = networks.map(network => {
                const signalClass = network.signal > 70 ? 'signal-strong' : 
                                  network.signal > 40 ? 'signal-medium' : 'signal-weak';
                
                return `
                    <div class="wifi-network" data-ssid="${network.ssid}">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <strong>${network.ssid}</strong>
                                <i class="fas fa-wifi ms-2"></i>
                            </div>
                            <div class="signal-strength ${signalClass}">
                                ${network.signal}%
                            </div>
                        </div>
                    </div>
                `;
            }).join('');

            // Add click handlers to network items
            document.querySelectorAll('.wifi-network').forEach(item => {
                item.addEventListener('click', (e) => {
                    // Remove previous selection
                    document.querySelectorAll('.wifi-network').forEach(n => n.classList.remove('selected'));
                    // Select current
                    e.currentTarget.classList.add('selected');
                    // Fill SSID field
                    document.getElementById('wifi-ssid').value = e.currentTarget.getAttribute('data-ssid');
                });
            });

        } catch (error) {
            this.showError('WiFi scan failed: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    async handleWiFiConnect(e) {
        try {
            this.showLoading(true);
            const ssid = document.getElementById('wifi-ssid').value;
            const password = document.getElementById('wifi-password').value;
            
            const result = await auraAPI.connectWiFi(ssid, password);
            const resultDiv = document.getElementById('wifi-connect-result');
            
            if (result.success) {
                resultDiv.innerHTML = `
                    <div class="alert alert-success">
                        <h6>Connected Successfully!</h6>
                        <p>${result.message}</p>
                    </div>
                `;
                document.getElementById('wifi-connect-form').reset();
            } else {
                resultDiv.innerHTML = `
                    <div class="alert alert-danger">
                        <h6>Connection Failed</h6>
                        <p>${result.message}</p>
                    </div>
                `;
            }
        } catch (error) {
            this.showError('WiFi connection failed: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    setupSensorEvents() {
        // Refresh sensors button
        document.getElementById('refresh-sensors')?.addEventListener('click', async () => {
            await this.loadSensorData();
        });
    }

    async loadSensorData() {
        try {
            const sensorData = await auraAPI.getSensorData();
            
            // Update sensor displays
            document.getElementById('sensor-temperature').textContent = `${sensorData.temperature}°C`;
            document.getElementById('sensor-humidity').textContent = `${sensorData.humidity}%`;
            document.getElementById('sensor-light').textContent = `${sensorData.light} lux`;
            document.getElementById('sensor-motion').textContent = sensorData.motion ? 'Detected' : 'None';

            // Update sensor history chart
            if (this.charts.sensorHistory) {
                const now = new Date().toLocaleTimeString();
                const chart = this.charts.sensorHistory;
                
                chart.data.labels.push(now);
                chart.data.datasets[0].data.push(sensorData.temperature);
                chart.data.datasets[1].data.push(sensorData.humidity);
                
                // Keep only last 20 data points
                if (chart.data.labels.length > 20) {
                    chart.data.labels.shift();
                    chart.data.datasets[0].data.shift();
                    chart.data.datasets[1].data.shift();
                }
                
                chart.update();
            }
        } catch (error) {
            console.error('Error loading sensor data:', error);
        }
    }

    setupSystemEvents() {
        // Command form
        document.getElementById('command-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleCommand(e);
        });

        // OTA form
        document.getElementById('ota-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleOTA(e);
        });

        // Data management buttons
        document.getElementById('backup-data')?.addEventListener('click', async () => {
            await this.backupData();
        });

        document.getElementById('sync-firebase')?.addEventListener('click', async () => {
            await this.syncFirebase();
        });

        document.getElementById('drive-backup')?.addEventListener('click', async () => {
            await this.driveBackup();
        });

        // Restore form
        document.getElementById('restore-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleRestore(e);
        });

        // Storage info
        document.getElementById('refresh-storage')?.addEventListener('click', async () => {
            await this.loadStorageInfo();
        });

        // System control buttons
        document.getElementById('dream-mode')?.addEventListener('click', async () => {
            await this.activateDreamMode();
        });

        document.getElementById('gesture-detect')?.addEventListener('click', async () => {
            await this.detectGesture();
        });

        document.getElementById('webrtc-status')?.addEventListener('click', async () => {
            await this.checkWebRTCStatus();
        });

        document.getElementById('system-status')?.addEventListener('click', async () => {
            await this.checkSystemStatus();
        });
    }

    async handleCommand(e) {
        try {
            const command = document.getElementById('command-input').value;
            const result = await auraAPI.executeCommand(command);
            
            document.getElementById('command-output').textContent = result.output;
            document.getElementById('command-input').value = '';
        } catch (error) {
            document.getElementById('command-output').textContent = 'Error: ' + error.message;
        }
    }

    async handleOTA(e) {
        try {
            this.showLoading(true);
            const formData = new FormData();
            formData.append('firmware', document.getElementById('firmware-file').files[0]);

            const result = await auraAPI.otaUpdate(formData);
            document.getElementById('ota-result').innerHTML = `
                <div class="alert alert-success">
                    <h6>OTA Update Complete</h6>
                    <p>Status: ${result.status}</p>
                </div>
            `;
        } catch (error) {
            this.showError('OTA update failed: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    async backupData() {
        try {
            const blob = await auraAPI.backupData();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'aura_backup.json';
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
            this.showSuccess('Data backup downloaded!');
        } catch (error) {
            this.showError('Backup failed: ' + error.message);
        }
    }

    async syncFirebase() {
        try {
            this.showLoading(true);
            await auraAPI.syncFirebase();
            this.showSuccess('Data synced to Firebase successfully!');
        } catch (error) {
            this.showError('Firebase sync failed: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    async driveBackup() {
        try {
            this.showLoading(true);
            const result = await auraAPI.driveBackup();
            this.showSuccess('Data backed up to Google Drive!');
        } catch (error) {
            this.showError('Drive backup failed: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    async handleRestore(e) {
        try {
            this.showLoading(true);
            const formData = new FormData();
            formData.append('file', document.getElementById('restore-file').files[0]);

            await auraAPI.restoreData(formData);
            this.showSuccess('Data restored successfully!');
            document.getElementById('restore-form').reset();
        } catch (error) {
            this.showError('Data restore failed: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    async loadStorageInfo() {
        try {
            const storageInfo = await auraAPI.getStorageInfo();
            const container = document.getElementById('storage-info');
            
            container.innerHTML = Object.entries(storageInfo).map(([folder, size]) => `
                <div class="storage-item">
                    <span class="storage-label">${folder}:</span>
                    <span class="storage-size">${size}</span>
                </div>
            `).join('');
        } catch (error) {
            console.error('Error loading storage info:', error);
        }
    }

    async activateDreamMode() {
        try {
            await auraAPI.activateDreamMode();
            this.showSuccess('Dream mode activated!');
        } catch (error) {
            this.showError('Failed to activate dream mode: ' + error.message);
        }
    }

    async detectGesture() {
        try {
            const result = await auraAPI.detectGesture();
            this.showSuccess(`Gesture detected: ${result.gesture}`);
        } catch (error) {
            this.showError('Gesture detection failed: ' + error.message);
        }
    }

    async checkWebRTCStatus() {
        try {
            const result = await auraAPI.getWebRTCStatus();
            this.showInfo(`WebRTC Status: ${result.call_active ? 'Active' : 'Inactive'}`);
        } catch (error) {
            this.showError('Failed to check WebRTC status: ' + error.message);
        }
    }

    async checkSystemStatus() {
        try {
            const result = await auraAPI.getSystemStatus();
            this.showInfo('System status checked - see console for details');
            console.log('System Status:', result);
        } catch (error) {
            this.showError('Failed to check system status: ' + error.message);
        }
    }

    setupImagePreviews() {
        // Image preview for file inputs
        const imageInputs = [
            'face-image', 'recognize-image', 'detect-image', 'emotion-image', 
            'ocr-image', 'capture-image', 'upload-image'
        ];

        imageInputs.forEach(inputId => {
            const input = document.getElementById(inputId);
            if (input) {
                input.addEventListener('change', (e) => {
                    const file = e.target.files[0];
                    const previewId = inputId.replace('-image', '-preview');
                    const preview = document.getElementById(previewId);
                    
                    if (file && preview) {
                        const reader = new FileReader();
                        reader.onload = (e) => {
                            preview.src = e.target.result;
                            preview.style.display = 'block';
                        };
                        reader.readAsDataURL(file);
                    }
                });
            }
        });
    }

    async handleUnlock() {
        try {
            const pin = document.getElementById('pin-input').value;
            const result = await auraAPI.unlock(pin);
            
            if (result.unlocked) {
                this.isUnlocked = true;
                this.showSuccess('Access granted!');
                const modal = bootstrap.Modal.getInstance(document.getElementById('unlockModal'));
                modal.hide();
                document.getElementById('unlock-btn').innerHTML = '<i class="fas fa-unlock"></i> Unlocked';
                document.getElementById('unlock-btn').classList.replace('btn-outline-light', 'btn-success');
            } else {
                this.showError('Invalid PIN!');
            }
            
            document.getElementById('pin-input').value = '';
        } catch (error) {
            this.showError('Unlock failed: ' + error.message);
        }
    }

    startAutoRefresh() {
        // Auto-refresh dashboard every 30 seconds
        this.refreshIntervals.dashboard = setInterval(() => {
            if (this.currentSection === 'dashboard') {
                this.loadSensorChart();
                this.refreshCameraFeed();
            }
        }, 30000);

        // Auto-refresh sensors every 10 seconds
        this.refreshIntervals.sensors = setInterval(() => {
            if (this.currentSection === 'sensors') {
                this.loadSensorData();
            }
        }, 10000);
    }

    stopAutoRefresh() {
        Object.values(this.refreshIntervals).forEach(interval => {
            clearInterval(interval);
        });
        this.refreshIntervals = {};
    }

    // Utility methods
    showLoading(show) {
        const spinner = document.getElementById('loading-spinner');
        if (spinner) {
            spinner.classList.toggle('d-none', !show);
        }
    }

    showSuccess(message) {
        this.showToast(message, 'success');
    }

    showError(message) {
        this.showToast(message, 'danger');
    }

    showInfo(message) {
        this.showToast(message, 'info');
    }

    showToast(message, type = 'info') {
        // Create toast element
        const toastHtml = `
            <div class="toast align-items-center text-white bg-${type} border-0" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="d-flex">
                    <div class="toast-body">
                        ${message}
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            </div>
        `;

        // Create toast container if it doesn't exist
        let toastContainer = document.getElementById('toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.id = 'toast-container';
            toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
            document.body.appendChild(toastContainer);
        }

        // Add toast to container
        toastContainer.insertAdjacentHTML('beforeend', toastHtml);
        
        // Initialize and show toast
        const toastElement = toastContainer.lastElementChild;
        const toast = new bootstrap.Toast(toastElement);
        toast.show();

        // Remove toast after it's hidden
        toastElement.addEventListener('hidden.bs.toast', () => {
            toastElement.remove();
        });
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.auraDashboard = new AuraDashboard();
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (window.auraDashboard) {
        window.auraDashboard.stopAutoRefresh();
    }
});

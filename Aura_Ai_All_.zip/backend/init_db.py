import sqlite3

# FACE MEMORY DB
conn1 = sqlite3.connect('face_memory.db')
cur1 = conn1.cursor()
cur1.execute('''
CREATE TABLE IF NOT EXISTS faces (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    relationship TEXT,
    notes TEXT,
    first_seen TEXT,
    last_seen TEXT,
    face_encoding TEXT
)
''')
conn1.commit()
conn1.close()

# MEMORY DB
conn2 = sqlite3.connect('memory.db')
cur2 = conn2.cursor()
cur2.execute('''
CREATE TABLE IF NOT EXISTS memories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT,
    type TEXT,
    question TEXT,
    answer TEXT,
    language TEXT,
    is_private INTEGER DEFAULT 0,
    tags TEXT
)
''')
cur2.execute('''
CREATE TABLE IF NOT EXISTS image_memory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    description TEXT,
    path TEXT,
    timestamp TEXT,
    ocr_text TEXT,
    emotions TEXT
)
''')
cur2.execute('''
CREATE TABLE IF NOT EXISTS voice_memory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT,
    original_text TEXT,
    translated_text TEXT,
    language TEXT,
    audio_path TEXT
)
''')
cur2.execute('''
CREATE TABLE IF NOT EXISTS emotions_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT,
    emotion TEXT,
    confidence REAL,
    face_id INTEGER
)
''')
conn2.commit()
conn2.close()

# AURA SYSTEM DB
conn3 = sqlite3.connect('aura.db')
cur3 = conn3.cursor()
cur3.execute('''
CREATE TABLE IF NOT EXISTS surveillance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT,
    timestamp TEXT,
    detected_faces TEXT,
    activity_level TEXT
)
''')
cur3.execute('''
CREATE TABLE IF NOT EXISTS system_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT,
    event_type TEXT,
    message TEXT,
    severity TEXT
)
''')
cur3.execute('''
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT,
    updated_at TEXT
)
''')
conn3.commit()
conn3.close()

print("✅ All 3 databases created: face_memory.db, memory.db, aura.db")
